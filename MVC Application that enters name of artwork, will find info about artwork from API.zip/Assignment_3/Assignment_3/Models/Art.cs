﻿using Assignment_3.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Text.Json;

namespace Assignment_3.Models
{
  

    public class ArtworkResponse
    {
        [JsonProperty("data")]
        public List<Art> Data { get; set; }
    }

    public class Art
    {
        [JsonProperty("id")]
        public int Id { get; set; }

        [JsonProperty("title")]
        public string? Title { get; set; }

        [JsonProperty("artist_title")]
        public string? ArtistTitle { get; set; }

        [JsonProperty("image_id")]
        public string? ImageId { get; set; }

        [JsonProperty("date_display")]
        public string? DateDisplay { get; set; }

        [JsonProperty("medium_display")]
        public string? MediumDisplay { get; set; }
    }
}