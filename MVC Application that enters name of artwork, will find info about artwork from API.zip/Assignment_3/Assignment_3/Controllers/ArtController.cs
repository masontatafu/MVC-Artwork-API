﻿using Microsoft.AspNetCore.Mvc;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using System;
using Assignment_3.Models;


namespace Assignment_3.Controllers
{
    public class ArtController : Controller
    {
        public IActionResult Index()
        {
            return RedirectToAction("Index", "Home"); // Redirects to home page
        }

        public IActionResult SearchArt()
        {
            return View(); 
        }

        public async Task<IActionResult> Search(string query)
        {
            if (string.IsNullOrEmpty(query))
            {
                return RedirectToAction("SearchArt"); // Redirects to the search page instead of Index
            }

            string apiUrl = $"https://api.artic.edu/api/v1/artworks/search?q={query}&fields=id,title,artist_title,image_id,date_display,medium_display&page=1&limit=10";

            try
            {
                using HttpClient client = new HttpClient();
                client.DefaultRequestHeaders.Add("User-Agent", "Mozilla/5.0");

                HttpResponseMessage response = await client.GetAsync(apiUrl);
                response.EnsureSuccessStatusCode();

                string json = await response.Content.ReadAsStringAsync();

                var data = JsonConvert.DeserializeObject<ArtworkResponse>(json); // Using Newtonsoft.Json

                return View("Results", data?.Data); // Pass artworks to the view
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Error fetching artwork.";
                return RedirectToAction("SearchArt"); // Redirect to search page on error
            }
        }
    }
}